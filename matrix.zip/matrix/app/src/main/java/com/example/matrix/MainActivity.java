package com.example.matrix;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button btn;
    private EditText aa;
    private EditText ab;
    private EditText ba;
    private EditText bb;
    private TextView vivod;
    private Button Go3x3;
    private Button GoMult;
    private Button GoSLAU;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        overridePendingTransition(0,0);

        GoSLAU = findViewById(R.id.SLAU);
        GoMult = findViewById(R.id.button8);
        Go3x3 = findViewById(R.id.button6);
        btn = findViewById(R.id.button);
        aa = findViewById(R.id.aa);
        ab = findViewById(R.id.ab);
        ba = findViewById(R.id.ba);
        bb = findViewById(R.id.bb);
        vivod = findViewById(R.id.vivod);
        aa.setText("0");
        ab.setText("0");
        ba.setText("0");
        bb.setText("0");

        Go3x3.setOnClickListener(view ->
                {
                    Intent intent = new Intent(this, MainActivity2.class);
                    startActivity(intent);
                }
        );

        GoMult.setOnClickListener(view ->
                {
                    Intent intent = new Intent(this, MainActivity3.class);
                    startActivity(intent);
                }
        );

        GoSLAU.setOnClickListener(view ->
                {
                    Intent intent = new Intent(this, MainActivity4.class);
                    startActivity(intent);
                }
        );

        btn.setOnClickListener( view ->
                {
                    int AA = Integer.parseInt(aa.getText().toString());
                    int AB = Integer.parseInt(ab.getText().toString());
                    int BA = Integer.parseInt(ba.getText().toString());
                    int BB = Integer.parseInt(bb.getText().toString());
                    int res = AA*BB-AB*BA;
                    String r =  String.valueOf(res);
                    vivod.setText(r);

                });
    }
}