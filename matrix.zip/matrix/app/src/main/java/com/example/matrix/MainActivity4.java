package com.example.matrix;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity4 extends AppCompatActivity {
    private Button btn;
    private Button btn2;
    private EditText aa;
    private EditText ab;
    private EditText ac;
    private EditText ba;
    private EditText bb;
    private EditText bc;
    private EditText ca;
    private EditText cb;
    private EditText cc;
    private TextView vivod;
    private Button Go2x2;
    private Button GoMult;
    private EditText XX;
    private EditText YY;
    private EditText ZZ;
    private Button Go3x3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        overridePendingTransition(0,0);


        Go3x3 = findViewById(R.id.b3x3);
        XX = findViewById(R.id.x);
        YY = findViewById(R.id.y);
        ZZ = findViewById(R.id.z);
        GoMult = findViewById(R.id.button11);
        Go2x2 = findViewById(R.id.button10);
        btn = findViewById(R.id.button9);
        btn2 = findViewById(R.id.button12);
        aa = findViewById(R.id.aa5);
        ab = findViewById(R.id.ab5);
        ac = findViewById(R.id.ac);
        ba = findViewById(R.id.ba5);
        bb = findViewById(R.id.bb5);
        bc = findViewById(R.id.bc);
        ca = findViewById(R.id.ca);
        cb = findViewById(R.id.cb);
        cc = findViewById(R.id.cc);
        vivod = findViewById(R.id.vivod4);
        aa.setText("0");
        ab.setText("0");
        ac.setText("0");
        ba.setText("0");
        bb.setText("0");
        bc.setText("0");
        ca.setText("0");
        cb.setText("0");
        cc.setText("0");
        XX.setText("0");
        YY.setText("0");
        ZZ.setText("0");

        Go2x2.setOnClickListener(view ->
                {
                    Intent intent = new Intent(this, MainActivity.class);
                    startActivity(intent);
                }
        );

        GoMult.setOnClickListener(view ->
                {
                    Intent intent = new Intent(this, MainActivity3.class);
                    startActivity(intent);
                }
        );

        Go3x3.setOnClickListener(view ->
                {
                    Intent intent = new Intent(this, MainActivity2.class);
                    startActivity(intent);
                }
        );

        btn.setOnClickListener( view ->
        {
            int AA = Integer.parseInt(aa.getText().toString());
            int AB = Integer.parseInt(ab.getText().toString());
            int AC = Integer.parseInt(ac.getText().toString());
            int BA = Integer.parseInt(ba.getText().toString());
            int BB = Integer.parseInt(bb.getText().toString());
            int BC = Integer.parseInt(bc.getText().toString());
            int CA = Integer.parseInt(ca.getText().toString());
            int CB = Integer.parseInt(cb.getText().toString());
            int CC = Integer.parseInt(cc.getText().toString());
            int res = AA*BB*CC+AB*BC*CA+AC*BA*CB-CA*BB*AC-CB*BC*AA-CC*BA*AB;

            int aa = BB*CC - CB*BC;
            int ab = BA*CC - CA*BC;
            int ac = BA*CB - CA*BB;
            int ba = AB*CC - CB*AC;
            int bb = AA*CC - CA*AC;
            int bc = AA*CB - CA*AB;
            int ca = AB*BC - BB*AC;
            int cb = AA*BC - BA*AC;
            int cc = AA*BB - BA*AB;


            if (CA == 0 && CB == 0 && CC == 0 && AC == 0 && BC == 0) {

                int res1 = AA*BB-AB*BA;
                int a1 = BB; int a2 = (-AB);
                int b1 = (-BA); int b2 = AA;

                vivod.setText(
                        a1 + "/" + res1 + "  " + a2 + "/" + res1 + "\n" +
                                b1 + "/" + res1 + "  " + b2 + "/" + res1 + " "

                );


            } else {


                int a1 = aa; int a2 = (-ba); int a3 = ca;
                int b1 = (-ab); int b2 = bb; int b3 = (-cb);
                int c1 = ac; int c2 = (-bc); int c3 = cc;


                vivod.setText(
                        a1 + "/" + res + " " + a2 + "/" + res + " " + a3 + "/" + res + "\n" +
                                b1 + "/" + res + " " + b2 + "/" + res + " " + b3 + "/" + res + "\n" +
                                c1 + "/" + res + " " + c2 + "/" + res + " " + c3 + "/" + res
                );
            }



        });

        btn2.setOnClickListener( view ->
        {
            int AA = Integer.parseInt(aa.getText().toString());
            int AB = Integer.parseInt(ab.getText().toString());
            int AC = Integer.parseInt(ac.getText().toString());
            int BA = Integer.parseInt(ba.getText().toString());
            int BB = Integer.parseInt(bb.getText().toString());
            int BC = Integer.parseInt(bc.getText().toString());
            int CA = Integer.parseInt(ca.getText().toString());
            int CB = Integer.parseInt(cb.getText().toString());
            int CC = Integer.parseInt(cc.getText().toString());
            int X = Integer.parseInt(XX.getText().toString());
            int Y = Integer.parseInt(YY.getText().toString());
            int Z = Integer.parseInt(ZZ.getText().toString());

            int aa = BB*CC - CB*BC;
            int ab = BA*CC - CA*BC;
            int ac = BA*CB - CA*BB;
            int ba = AB*CC - CB*AC;
            int bb = AA*CC - CA*AC;
            int bc = AA*CB - CA*AB;
            int ca = AB*BC - BB*AC;
            int cb = AA*BC - BA*AC;
            int cc = AA*BB - BA*AB;


            int res = AA*BB*CC+AB*BC*CA+AC*BA*CB-CA*BB*AC-CB*BC*AA-CC*BA*AB;

            if (CA == 0 && CB == 0 && CC == 0 && AC == 0 && BC == 0 && Z == 0) {

                double res1 = AA*BB-AB*BA;
                double Xr = (BB*X + -AB*Y) / res1;
                double Yr = (-BA*X + AA*Y) / res1;

                vivod.setText(
                        "X = " + Xr + "\n" +
                                "Y = " + Yr

                );


            }
            else {

                double Xr = (aa*X + -ba*Y + ca*Z) / res;
                double Yr = (-ab*X + bb*Y + -cb*Z) / res;
                double Zr = (ac*X + -bc*Y + cc*Z) / res;


                vivod.setText(
                        "X = " + Xr + "\n" +
                                "Y = " + Yr + "\n" +
                                "Z = " + Zr

                );
            }


        });
    }
}