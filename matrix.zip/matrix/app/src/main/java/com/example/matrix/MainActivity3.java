package com.example.matrix;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    private Button mult;
    private Button mult2;
    private Button mult3;
    private Button mult4;
    private EditText aa;
    private EditText ab;
    private EditText ac;
    private EditText ba;
    private EditText bb;
    private EditText bc;
    private EditText ca;
    private EditText cb;
    private EditText cc;
    private EditText aa2;
    private EditText ab2;
    private EditText ac2;
    private EditText ba2;
    private EditText bb2;
    private EditText bc2;
    private EditText ca2;
    private EditText cb2;
    private EditText cc2;
    private TextView vivod;
    private Button Go2x2;
    private Button Go3x3;
    private Button GoSLAU;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        overridePendingTransition(0,0);

        GoSLAU = findViewById(R.id.SLAU);
        Go3x3 = findViewById(R.id.button7);
        Go2x2 = findViewById(R.id.button5);
        mult = findViewById(R.id.mult);
        mult2 = findViewById(R.id.mult2);
        mult3 = findViewById(R.id.mult3);
        mult4 = findViewById(R.id.mult4);
        aa = findViewById(R.id.aa3);
        ab = findViewById(R.id.ab3);
        ac = findViewById(R.id.ac3);
        ba = findViewById(R.id.ba3);
        bb = findViewById(R.id.bb3);
        bc = findViewById(R.id.bc3);
        ca = findViewById(R.id.ca3);
        cb = findViewById(R.id.cb3);
        cc = findViewById(R.id.cc3);
        aa2 = findViewById(R.id.aa4);
        ab2 = findViewById(R.id.ab4);
        ac2 = findViewById(R.id.ac4);
        ba2 = findViewById(R.id.ba4);
        bb2 = findViewById(R.id.bb4);
        bc2 = findViewById(R.id.bc4);
        ca2 = findViewById(R.id.ca4);
        cb2 = findViewById(R.id.cb4);
        cc2 = findViewById(R.id.cc4);
        vivod = findViewById(R.id.vivod3);
        aa.setText("0");
        ab.setText("0");
        ac.setText("0");
        ba.setText("0");
        bb.setText("0");
        bc.setText("0");
        ca.setText("0");
        cb.setText("0");
        cc.setText("0");
        aa2.setText("0");
        ab2.setText("0");
        ac2.setText("0");
        ba2.setText("0");
        bb2.setText("0");
        bc2.setText("0");
        ca2.setText("0");
        cb2.setText("0");
        cc2.setText("0");


        Go2x2.setOnClickListener(view ->
                {
                    Intent intent = new Intent(this, MainActivity.class);
                    startActivity(intent);
                }
        );
        Go3x3.setOnClickListener(view ->
                {
                    Intent intent = new Intent(this, MainActivity2.class);
                    startActivity(intent);
                }
        );

        GoSLAU.setOnClickListener(view ->
                {
                    Intent intent = new Intent(this, MainActivity4.class);
                    startActivity(intent);
                }
        );


        mult4.setOnClickListener( view ->
                {
                    String a1 = aa.getText().toString();
                    String a2 = ab.getText().toString();
                    String a3 = ac.getText().toString();
                    String a4 = ba.getText().toString();
                    String a5 = bb.getText().toString();
                    String a6 = bc.getText().toString();
                    String a7 = ca.getText().toString();
                    String a8 = cb.getText().toString();
                    String a9 = cc.getText().toString();

                    aa.setText(aa2.getText().toString());
                    ab.setText(ab2.getText().toString());
                    ac.setText(ac2.getText().toString());
                    ba.setText(ba2.getText().toString());
                    bb.setText(bb2.getText().toString());
                    bc.setText(bc2.getText().toString());
                    ca.setText(ca2.getText().toString());
                    cb.setText(cb2.getText().toString());
                    cc.setText(cc2.getText().toString());

                    aa2.setText(a1);
                    ab2.setText(a2);
                    ac2.setText(a3);
                    ba2.setText(a4);
                    bb2.setText(a5);
                    bc2.setText(a6);
                    ca2.setText(a7);
                    cb2.setText(a8);
                    cc2.setText(a9);


                });

        mult.setOnClickListener( view ->
        {
            int AA = Integer.parseInt(aa.getText().toString());
            int AB = Integer.parseInt(ab.getText().toString());
            int AC = Integer.parseInt(ac.getText().toString());
            int BA = Integer.parseInt(ba.getText().toString());
            int BB = Integer.parseInt(bb.getText().toString());
            int BC = Integer.parseInt(bc.getText().toString());
            int CA = Integer.parseInt(ca.getText().toString());
            int CB = Integer.parseInt(cb.getText().toString());
            int CC = Integer.parseInt(cc.getText().toString());

            int AA2 = Integer.parseInt(aa2.getText().toString());
            int AB2 = Integer.parseInt(ab2.getText().toString());
            int AC2 = Integer.parseInt(ac2.getText().toString());
            int BA2 = Integer.parseInt(ba2.getText().toString());
            int BB2 = Integer.parseInt(bb2.getText().toString());
            int BC2 = Integer.parseInt(bc2.getText().toString());
            int CA2 = Integer.parseInt(ca2.getText().toString());
            int CB2 = Integer.parseInt(cb2.getText().toString());
            int CC2 = Integer.parseInt(cc2.getText().toString());

            int[][] res = new int[3][3];
            int[][] mas = {{AA, AB, AC}, {BA, BB, BC}, {CA, CB, CC}};
            int[][] mas2 = {{AA2, AB2, AC2}, {BA2, BB2, BC2}, {CA2, CB2, CC2}};
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    res[i][j] = 0;
                    for (int k = 0; k < 3; k++)
                    {
                        res[i][j] += mas[i][k] * mas2[k][j];
                    }
                }
            }


            vivod.setText(res[0][0] + " \t " + res[0][1] + " \t " + res[0][2] +"\n" +
                    res[1][0] + " \t " + res[1][1] + " \t " + res[1][2] +"\n" +
                    res[2][0] + " \t " + res[2][1] + " \t " + res[2][2]
            );
        });

        mult2.setOnClickListener( view ->
        {
            int AA = Integer.parseInt(aa.getText().toString());
            int AB = Integer.parseInt(ab.getText().toString());
            int AC = Integer.parseInt(ac.getText().toString());
            int BA = Integer.parseInt(ba.getText().toString());
            int BB = Integer.parseInt(bb.getText().toString());
            int BC = Integer.parseInt(bc.getText().toString());
            int CA = Integer.parseInt(ca.getText().toString());
            int CB = Integer.parseInt(cb.getText().toString());
            int CC = Integer.parseInt(cc.getText().toString());

            int AA2 = Integer.parseInt(aa2.getText().toString());
            int AB2 = Integer.parseInt(ab2.getText().toString());
            int AC2 = Integer.parseInt(ac2.getText().toString());
            int BA2 = Integer.parseInt(ba2.getText().toString());
            int BB2 = Integer.parseInt(bb2.getText().toString());
            int BC2 = Integer.parseInt(bc2.getText().toString());
            int CA2 = Integer.parseInt(ca2.getText().toString());
            int CB2 = Integer.parseInt(cb2.getText().toString());
            int CC2 = Integer.parseInt(cc2.getText().toString());

            int[] res = new int[9];
            int[] mas = {AA, AB, AC, BA, BB, BC, CA, CB, CC};
            int[] mas2 = {AA2, AB2, AC2, BA2, BB2, BC2, CA2, CB2, CC2};
            for (int i = 0; i < res.length ;i++)
            {
                res[i] = mas[i] - mas2[i];
            }

            vivod.setText(res[0] + " \t " + res[1] + " \t " + res[2] +"\n" +
                          res[3] + " \t " + res[4] + " \t " + res[5] +"\n" +
                          res[6] + " \t " + res[7] + " \t " + res[8]
            );
        });

        mult3.setOnClickListener( view ->
        {
            int AA = Integer.parseInt(aa.getText().toString());
            int AB = Integer.parseInt(ab.getText().toString());
            int AC = Integer.parseInt(ac.getText().toString());
            int BA = Integer.parseInt(ba.getText().toString());
            int BB = Integer.parseInt(bb.getText().toString());
            int BC = Integer.parseInt(bc.getText().toString());
            int CA = Integer.parseInt(ca.getText().toString());
            int CB = Integer.parseInt(cb.getText().toString());
            int CC = Integer.parseInt(cc.getText().toString());

            int AA2 = Integer.parseInt(aa2.getText().toString());
            int AB2 = Integer.parseInt(ab2.getText().toString());
            int AC2 = Integer.parseInt(ac2.getText().toString());
            int BA2 = Integer.parseInt(ba2.getText().toString());
            int BB2 = Integer.parseInt(bb2.getText().toString());
            int BC2 = Integer.parseInt(bc2.getText().toString());
            int CA2 = Integer.parseInt(ca2.getText().toString());
            int CB2 = Integer.parseInt(cb2.getText().toString());
            int CC2 = Integer.parseInt(cc2.getText().toString());

            int[] res = new int[9];
            int[] mas = {AA, AB, AC, BA, BB, BC, CA, CB, CC};
            int[] mas2 = {AA2, AB2, AC2, BA2, BB2, BC2, CA2, CB2, CC2};
            for (int i = 0; i < res.length ;i++)
            {
                res[i] = mas[i] + mas2[i];
            }

            vivod.setText(res[0] + " \t " + res[1] + " \t " + res[2] +"\n" +
                    res[3] + " \t " + res[4] + " \t " + res[5] +"\n" +
                    res[6] + " \t " + res[7] + " \t " + res[8]
            );
        });


    }
}