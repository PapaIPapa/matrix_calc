package com.example.matrix;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    private Button btn;
    private EditText aa;
    private EditText ab;
    private EditText ac;
    private EditText ba;
    private EditText bb;
    private EditText bc;
    private EditText ca;
    private EditText cb;
    private EditText cc;
    private TextView vivod;
    private Button Go2x2;
    private Button GoMult;
    private Button GoSLAU;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        overridePendingTransition(0,0);

        GoSLAU = findViewById(R.id.SLAU);
        GoMult = findViewById(R.id.button4);
        Go2x2 = findViewById(R.id.button3);
        btn = findViewById(R.id.button2);
        aa = findViewById(R.id.aa2);
        ab = findViewById(R.id.ab2);
        ac = findViewById(R.id.ac2);
        ba = findViewById(R.id.ba2);
        bb = findViewById(R.id.bb2);
        bc = findViewById(R.id.bc2);
        ca = findViewById(R.id.ca2);
        cb = findViewById(R.id.cb2);
        cc = findViewById(R.id.cc2);
        vivod = findViewById(R.id.vivod2);
        aa.setText("0");
        ab.setText("0");
        ac.setText("0");
        ba.setText("0");
        bb.setText("0");
        bc.setText("0");
        ca.setText("0");
        cb.setText("0");
        cc.setText("0");

        Go2x2.setOnClickListener(view ->
                {
                    Intent intent = new Intent(this, MainActivity.class);
                    startActivity(intent);
                }
                );

        GoMult.setOnClickListener(view ->
                {
                    Intent intent = new Intent(this, MainActivity3.class);
                    startActivity(intent);
                }
        );

        GoSLAU.setOnClickListener(view ->
                {
                    Intent intent = new Intent(this, MainActivity4.class);
                    startActivity(intent);
                }
        );

        btn.setOnClickListener( view ->
        {
            int AA = Integer.parseInt(aa.getText().toString());
            int AB = Integer.parseInt(ab.getText().toString());
            int AC = Integer.parseInt(ac.getText().toString());
            int BA = Integer.parseInt(ba.getText().toString());
            int BB = Integer.parseInt(bb.getText().toString());
            int BC = Integer.parseInt(bc.getText().toString());
            int CA = Integer.parseInt(ca.getText().toString());
            int CB = Integer.parseInt(cb.getText().toString());
            int CC = Integer.parseInt(cc.getText().toString());
            int res = AA*BB*CC+AB*BC*CA+AC*BA*CB-CA*BB*AC-CB*BC*AA-CC*BA*AB;
            String r =  String.valueOf(res);
            vivod.setText(r);

        });
    }
}